require('dotenv').config();
const mongoose = require('mongoose');
const Crop     = require('./models/Crop');
const District = require('./models/District');
const Farmer   = require('./models/Farmer');
const Plan     = require('./models/Plan');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/cropiq';

const CROPS = [
  // ── Kharif ───────────────────────────────────────────────────────────────
  { name:'Ragi (Finger Millet)', emoji:'🌾', season:'kharif', profit:38000, risk:'Low',
    reason:"Karnataka's staple crop — thrives in red laterite soils of Kolar, Tumakuru, and Hassan districts. High government MSP support with guaranteed procurement.",
    cal:[{m:'June',t:'Land prep & sowing'},{m:'July',t:'Thinning & weeding'},{m:'Aug',t:'Fertilizer application'},{m:'Sep',t:'Pest control'},{m:'Oct',t:'Harvesting'},{m:'Nov',t:'Sale & storage'}]},
  { name:'Areca Nut (Betel)', emoji:'🥥', season:'kharif', profit:68000, risk:'Low',
    reason:"Very high demand and premium prices — coastal Karnataka specialty. Steady export market with strong MSP backing.",
    cal:[{m:'June',t:'Nursery prep'},{m:'July',t:'Planting'},{m:'Aug',t:'Irrigation & manure'},{m:'Sep',t:'Pest scouting'},{m:'Oct',t:'Bunch tying'},{m:'Nov',t:'First harvest'}]},
  { name:'Maize', emoji:'🌽', season:'kharif', profit:35000, risk:'High',
    reason:"Multi-purpose crop popular in North Karnataka. Weather-sensitive during grain fill — plan irrigation carefully.",
    cal:[{m:'June',t:'Sowing'},{m:'July',t:'Fertilizer dose'},{m:'Aug',t:'Tasseling'},{m:'Sep',t:'Grain filling'},{m:'Oct',t:'Harvest & dry'},{m:'Nov',t:'Storage & sale'}]},

  // ── Rabi ─────────────────────────────────────────────────────────────────
  { name:'Sunflower', emoji:'🌻', season:'rabi', profit:44000, risk:'Low',
    reason:"Karnataka is India's top sunflower producer. Excellent oil content, stable market price, low water requirements.",
    cal:[{m:'Oct',t:'Soil prep & sowing'},{m:'Nov',t:'Thinning & weeding'},{m:'Dec',t:'Irrigation'},{m:'Jan',t:'Flowering'},{m:'Feb',t:'Seed development'},{m:'Mar',t:'Harvest & oil mill'}]},
  { name:'Chickpea (Bengal Gram)', emoji:'🫛', season:'rabi', profit:32000, risk:'Medium',
    reason:"North Karnataka staple — drought tolerant, fixes nitrogen, and growing pulses market.",
    cal:[{m:'Oct',t:'Land prep'},{m:'Nov',t:'Sowing'},{m:'Dec',t:'Vegetative growth'},{m:'Jan',t:'Flowering'},{m:'Feb',t:'Podding'},{m:'Mar',t:'Harvest & market'}]},
  { name:'Wheat', emoji:'🌿', season:'rabi', profit:40000, risk:'Low',
    reason:"Stable government MSP procurement assured. Ideal for black and loamy soils in cool Rabi season.",
    cal:[{m:'Nov',t:'Land preparation'},{m:'Dec',t:'Sowing'},{m:'Jan',t:'Irrigation & fertilizer'},{m:'Feb',t:'Weed control'},{m:'Mar',t:'Grain development'},{m:'Apr',t:'Harvest & MSP sale'}]},

  // ── Zaid ─────────────────────────────────────────────────────────────────
  { name:'Watermelon', emoji:'🍉', season:'zaid', profit:58000, risk:'Medium',
    reason:"Very high summer demand, quick 70-day cycle, premium prices in Bengaluru market.",
    cal:[{m:'Mar',t:'Direct sow / nursery'},{m:'Apr',t:'Irrigation & training'},{m:'May',t:'Flowering & pollination'},{m:'June',t:'Fruit development'},{m:'July',t:'Harvest & sale'},{m:'Aug',t:'Land preparation'}]},
  { name:'Groundnut', emoji:'🥜', season:'zaid', profit:42000, risk:'Low',
    reason:"Karnataka is a top groundnut producer. Very good export and oil mill market year-round.",
    cal:[{m:'Mar',t:'Seed bed prep'},{m:'Apr',t:'Sowing'},{m:'May',t:'Earthing up'},{m:'June',t:'Pod development'},{m:'July',t:'Harvest'},{m:'Aug',t:'Drying & sale'}]},
  { name:'Bitter Gourd', emoji:'🫑', season:'zaid', profit:30000, risk:'High',
    reason:"Niche medicinal crop with premium market pricing in Bengaluru. Highly sensitive to temperature swings.",
    cal:[{m:'Feb',t:'Seed soaking & sow'},{m:'Mar',t:'Transplanting'},{m:'Apr',t:'Trellis setup'},{m:'May',t:'Flowering & fruiting'},{m:'June',t:'Harvest begins'},{m:'July',t:'Final sale'}]},

  // ── Year-round ────────────────────────────────────────────────────────────
  { name:'Sugarcane', emoji:'🎋', season:'yearround', profit:75000, risk:'Low',
    reason:"Mandya and Belagavi are Karnataka's sugarcane heartland. Long 12-18 month cycle with extremely high per-acre returns.",
    cal:[{m:'Jan',t:'Planting / ratoon'},{m:'Mar',t:'Fertilizer application'},{m:'Jun',t:'Earthing up'},{m:'Sep',t:'Irrigation boost'},{m:'Nov',t:'Harvesting begins'},{m:'Jan+',t:'Sugar mill delivery'}]},
  { name:'Banana', emoji:'🍌', season:'yearround', profit:62000, risk:'Medium',
    reason:"Davangere, Shivamogga and coastal Karnataka are key banana belts. Year-round demand, high profitability.",
    cal:[{m:'Any',t:'Sucker planting'},{m:'+2m',t:'Fertilizer & irrigation'},{m:'+5m',t:'Bunch emergence'},{m:'+8m',t:'Bunch protection'},{m:'+11m',t:'Harvest'},{m:'+12m',t:'Market & ratoon'}]},
  { name:'Turmeric', emoji:'🟡', season:'yearround', profit:48000, risk:'Medium',
    reason:"Rising global export demand for organic turmeric. Hassan and Kodagu districts produce premium quality.",
    cal:[{m:'Apr',t:'Rhizome planting'},{m:'Jun',t:'Weeding & earthing'},{m:'Aug',t:'Fertilizer dose'},{m:'Oct',t:'Growth stage'},{m:'Jan',t:'Harvesting'},{m:'Feb',t:'Curing & market sale'}]},
];

const DISTRICTS = [
  {name:'Mandya',     farmers:340, plans:1240, heat:'high'},
  {name:'Mysuru',     farmers:280, plans:980,  heat:'high'},
  {name:'Bengaluru',  farmers:220, plans:860,  heat:'high'},
  {name:'Belagavi',   farmers:195, plans:740,  heat:'mid'},
  {name:'Shivamogga', farmers:175, plans:620,  heat:'mid'},
  {name:'Hassan',     farmers:160, plans:580,  heat:'mid'},
  {name:'Tumakuru',   farmers:145, plans:510,  heat:'mid'},
  {name:'Kalaburagi', farmers:130, plans:440,  heat:'mid'},
  {name:'Vijayapura', farmers:110, plans:380,  heat:'low'},
  {name:'Raichur',    farmers:95,  plans:320,  heat:'low'},
  {name:'Davangere',  farmers:85,  plans:290,  heat:'low'},
  {name:'Dharwad',    farmers:70,  plans:240,  heat:'low'},
];

const FARMERS = [
  {farmerId:'001', name:'Ramesh Kumar',  district:'Mysuru',     plans:12, topCrop:'Sugarcane', topCropEmoji:'🎋', status:'Active'},
  {farmerId:'002', name:'Priya Nair',    district:'Belagavi',   plans:8,  topCrop:'Sunflower',  topCropEmoji:'🌻', status:'Active'},
  {farmerId:'003', name:'Suresh Gowda',  district:'Mandya',     plans:22, topCrop:'Sugarcane', topCropEmoji:'🎋', status:'Active'},
  {farmerId:'004', name:'Kavya Patil',   district:'Tumakuru',   plans:3,  topCrop:'Ragi',       topCropEmoji:'🌾', status:'Pending'},
  {farmerId:'005', name:'Mohan Das',     district:'Kalaburagi', plans:6,  topCrop:'Chickpea',  topCropEmoji:'🫛', status:'Active'},
  {farmerId:'006', name:'Anjali Hegde',  district:'Shivamogga', plans:9,  topCrop:'Banana',    topCropEmoji:'🍌', status:'Active'},
  {farmerId:'007', name:'Venkat Reddy',  district:'Raichur',    plans:4,  topCrop:'Groundnut', topCropEmoji:'🥜', status:'Inactive'},
  {farmerId:'008', name:'Lakshmi Devi',  district:'Hassan',     plans:15, topCrop:'Turmeric',  topCropEmoji:'🟡', status:'Active'},
];

const PLANS = [
  {farmerName:'Ramesh Kumar',  location:'Mysuru, Karnataka',     soil:'red',    area:5,  budget:30000, season:'yearround',  topCrop:'Sugarcane', topCropEmoji:'🎋', water:'canal'},
  {farmerName:'Priya Nair',    location:'Belagavi, Karnataka',   soil:'black',  area:3,  budget:15000, season:'rabi',       topCrop:'Sunflower',  topCropEmoji:'🌻', water:'rain'},
  {farmerName:'Suresh Gowda',  location:'Mandya, Karnataka',     soil:'alluvial',area:8, budget:50000, season:'yearround',  topCrop:'Sugarcane', topCropEmoji:'🎋', water:'canal'},
  {farmerName:'Anjali Hegde',  location:'Shivamogga, Karnataka', soil:'loamy',  area:4,  budget:20000, season:'yearround',  topCrop:'Banana',    topCropEmoji:'🍌', water:'borewell'},
  {farmerName:'Venkat Reddy',  location:'Raichur, Karnataka',    soil:'red',    area:2,  budget:10000, season:'zaid',       topCrop:'Groundnut', topCropEmoji:'🥜', water:'rain'},
];

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ Connected to MongoDB');

    // Clear collections
    await Promise.all([
      Crop.deleteMany({}),
      District.deleteMany({}),
      Farmer.deleteMany({}),
      Plan.deleteMany({})
    ]);
    console.log('🗑  Cleared existing data');

    await Crop.insertMany(CROPS);
    console.log(`🌾 Inserted ${CROPS.length} crops`);

    await District.insertMany(DISTRICTS);
    console.log(`📍 Inserted ${DISTRICTS.length} districts`);

    // Insert farmers without triggering pre-save hook (they already have farmerId)
    await Farmer.insertMany(FARMERS);
    console.log(`👨‍🌾 Inserted ${FARMERS.length} farmers`);

    await Plan.insertMany(PLANS);
    console.log(`📋 Inserted ${PLANS.length} plans`);

    console.log('\n✅ Database seeded successfully!');
    console.log('   Run: node server.js');
  } catch (err) {
    console.error('❌ Seed failed:', err.message);
  } finally {
    await mongoose.disconnect();
  }
}

seed();
