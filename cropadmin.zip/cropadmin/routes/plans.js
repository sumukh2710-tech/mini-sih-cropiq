const express = require('express');
const router  = express.Router();
const Plan    = require('../models/Plan');

// GET /api/plans — recent activity log (last 20)
router.get('/', async (req, res) => {
  try {
    const plans = await Plan.find().sort({ createdAt: -1 }).limit(20);
    res.json({ success: true, data: plans });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/plans — save a newly generated plan
router.post('/', async (req, res) => {
  try {
    const plan = new Plan(req.body);
    await plan.save();
    res.status(201).json({ success: true, data: plan });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

module.exports = router;
