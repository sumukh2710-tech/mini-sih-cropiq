const express = require('express');
const router = express.Router();
const District = require('../models/District');

// GET /api/districts — all district heatmap data
router.get('/', async (req, res) => {
  try {
    const districts = await District.find().sort({ plans: -1 });
    res.json({ success: true, data: districts });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/districts/:name/increment — bump plans count when a plan is generated
router.post('/:name/increment', async (req, res) => {
  try {
    const district = await District.findOneAndUpdate(
      { name: req.params.name },
      { $inc: { plans: 1 } },
      { new: true }
    );
    if (!district) return res.status(404).json({ success: false, message: 'District not found' });
    res.json({ success: true, data: district });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
