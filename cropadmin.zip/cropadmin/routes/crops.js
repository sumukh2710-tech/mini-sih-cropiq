const express = require('express');
const router = express.Router();
const Crop = require('../models/Crop');

// GET /api/crops?season=kharif&soil=red&area=5&budget=25000
// Returns sorted crop recommendations for the given inputs
router.get('/', async (req, res) => {
  try {
    const { season = 'yearround', soil = '', area = 1, budget = 0 } = req.query;
    const areaNum   = parseFloat(area)   || 1;
    const budgetNum = parseFloat(budget) || 0;

    const crops = await Crop.find({ season });

    const riskPenalty = { Low: 0, Medium: 0.05, High: 0.15 };

    const ranked = crops.map(c => {
      const scaledProfit  = Math.round(c.profit * areaNum);
      const budgetPerAcre = budgetNum / areaNum;
      const penalty       = budgetPerAcre < 15000 ? (riskPenalty[c.risk] || 0) : 0;
      return {
        _id:    c._id,
        name:   c.name,
        emoji:  c.emoji,
        season: c.season,
        profit: scaledProfit,
        risk:   c.risk,
        reason: c.reason,
        cal:    c.cal,
        score:  scaledProfit * (1 - penalty)
      };
    }).sort((a, b) => b.score - a.score);

    res.json({ success: true, data: ranked });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/crops/all — return all crops grouped by season (for admin analytics)
router.get('/all', async (req, res) => {
  try {
    const crops = await Crop.find().sort({ season: 1, profit: -1 });
    res.json({ success: true, data: crops });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
