const express  = require('express');
const router   = express.Router();
const Plan     = require('../models/Plan');
const Farmer   = require('../models/Farmer');
const District = require('../models/District');

// GET /api/dashboard/stats — KPI cards
router.get('/stats', async (req, res) => {
  try {
    const totalFarmers = await Farmer.countDocuments();
    const totalPlans   = await Plan.countDocuments();
    const districts    = await District.find();
    res.json({
      success: true,
      data: {
        totalFarmers,
        totalPlans,
        predictedProfitCr: '₹2.8Cr',
        accuracy: '98%',
        deltaFarmers: '↑ 18% this month',
        deltaPlans:   '↑ 34% this season',
        deltaProfit:  '↑ 22% YoY',
        deltaAccuracy:'↑ 2pts from last season'
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/dashboard/charts — all chart datasets
router.get('/charts', async (req, res) => {
  try {
    res.json({
      success: true,
      data: {
        activity: {
          labels: ['Nov','Dec','Jan','Feb','Mar','Apr'],
          plans:   [880,1140,1420,1680,2100,2401],
          farmers: [210,280,340,420,530,680]
        },
        cropDist: {
          labels: ['Sugarcane','Ragi','Banana','Sunflower','Watermelon','Others'],
          data:   [34,19,16,14,9,8]
        },
        season: {
          labels: ['Year-Round','Kharif','Rabi','Zaid'],
          data:   [42,28,18,12]
        },
        yieldTrend: {
          labels: ["Kh'23","Rb'23","Kh'24","Rb'24","Kh'25","Rb'25"],
          sugarcane: [68,69,70,71,73,76],
          banana:    [55,56,58,59,61,63],
          ragi:      [32,33,34,35,37,39]
        },
        rainfall: {
          labels: ['Apr W1','Apr W2','Apr W3','Apr W4','May W1','May W2','May W3','May W4'],
          bengaluru: [8,12,5,18,22,30,28,15],
          mandya:    [5,8,3,12,18,24,22,10],
          belagavi:  [2,1,0,4,6,8,5,2]
        },
        soilNutrient: {
          labels: ['Nitrogen','Phosphorus','Potassium','Organic C','Micronutrients','pH Balance'],
          red:      [72,65,80,58,45,70],
          black:    [85,70,75,78,60,65],
          alluvial: [90,85,88,82,75,80]
        },
        soilPh: {
          labels: ['<5.5','5.5–6.0','6.0–6.5','6.5–7.0','7.0–7.5','>7.5'],
          data:   [5,12,26,34,18,5]
        }
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/dashboard/activity — recent plan activity for log
router.get('/activity', async (req, res) => {
  try {
    const plans = await Plan.find().sort({ createdAt: -1 }).limit(10);
    res.json({ success: true, data: plans });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
