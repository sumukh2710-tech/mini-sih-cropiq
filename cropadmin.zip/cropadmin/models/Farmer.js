const mongoose = require('mongoose');

const farmerSchema = new mongoose.Schema({
  farmerId:  { type: String },
  name:      { type: String, required: true },
  district:  { type: String, required: true },
  plans:     { type: Number, default: 0 },
  topCrop:   { type: String, default: '' },
  topCropEmoji: { type: String, default: '' },
  status:    { type: String, enum: ['Active', 'Pending', 'Inactive'], default: 'Active' }
}, { timestamps: true });

// Auto-generate farmerId like 001, 002...
farmerSchema.pre('save', async function (next) {
  if (!this.farmerId) {
    const count = await mongoose.model('Farmer').countDocuments();
    this.farmerId = String(count + 1).padStart(3, '0');
  }
  next();
});

module.exports = mongoose.model('Farmer', farmerSchema);
