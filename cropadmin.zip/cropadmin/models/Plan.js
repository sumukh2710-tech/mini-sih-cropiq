const mongoose = require('mongoose');

const planSchema = new mongoose.Schema({
  location:  { type: String, required: true },
  soil:      { type: String, default: '' },
  area:      { type: Number, required: true },
  budget:    { type: Number, required: true },
  season:    { type: String, required: true },
  water:     { type: String, default: '' },
  topCrop:   { type: String, default: '' },
  topCropEmoji: { type: String, default: '' },
  farmerName: { type: String, default: 'Anonymous' }
}, { timestamps: true });

module.exports = mongoose.model('Plan', planSchema);
