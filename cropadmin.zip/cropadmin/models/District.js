const mongoose = require('mongoose');

const districtSchema = new mongoose.Schema({
  name:    { type: String, required: true, unique: true },
  farmers: { type: Number, default: 0 },
  plans:   { type: Number, default: 0 },
  heat:    { type: String, enum: ['high', 'mid', 'low'], default: 'mid' }
}, { timestamps: true });

module.exports = mongoose.model('District', districtSchema);
