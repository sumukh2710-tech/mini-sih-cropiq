const mongoose = require('mongoose');

const calEntrySchema = new mongoose.Schema({
  m: { type: String, required: true },
  t: { type: String, required: true }
}, { _id: false });

const cropSchema = new mongoose.Schema({
  name:    { type: String, required: true },
  emoji:   { type: String, default: '🌾' },
  season:  { type: String, enum: ['kharif', 'rabi', 'zaid', 'yearround'], required: true },
  profit:  { type: Number, required: true },   // base profit per acre
  risk:    { type: String, enum: ['Low', 'Medium', 'High'], default: 'Low' },
  reason:  { type: String, default: '' },
  cal:     { type: [calEntrySchema], default: [] }
}, { timestamps: true });

module.exports = mongoose.model('Crop', cropSchema);
