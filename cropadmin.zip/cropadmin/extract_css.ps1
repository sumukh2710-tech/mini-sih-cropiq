$html = [System.IO.File]::ReadAllText("cropiq-admin.html")
$start = $html.IndexOf("<style>") + 7
$end = $html.IndexOf("</style>")
$css = $html.Substring($start, $end - $start)
[System.IO.File]::WriteAllText("public\style.css", $css)
Write-Host "Done. Lines: $((Get-Content 'public\style.css').Count)"
