/* ═══════════════════════════════════════
   CropIQ — Login/Signup Logic
═══════════════════════════════════════ */

let isSignup = false;

document.getElementById('authToggleBtn').addEventListener('click', () => {
  isSignup = !isSignup;
  document.getElementById('nameField').style.display = isSignup ? 'block' : 'none';
  document.getElementById('roleField').style.display = isSignup ? 'block' : 'none';
  document.getElementById('authTitle').textContent = isSignup ? 'Create Account' : 'Welcome Back';
  document.getElementById('authBtn').textContent = isSignup ? 'Sign Up' : 'Sign In';
  document.getElementById('authToggleBtn').textContent = isSignup ? 'Already have an account? Sign in' : "Don't have an account? Sign up";
});

document.getElementById('authForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  
  const payload = { email, password };
  let endpoint = '/api/auth/login';

  if (isSignup) {
    const name = document.getElementById('name').value.trim();
    const role = document.getElementById('role').value;
    if (!name) {
      showToast('⚠️ Name is required for signup');
      return;
    }
    payload.name = name;
    payload.role = role;
    endpoint = '/api/auth/signup';
  }

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    
    const data = await res.json();
    if (!data.success) {
      throw new Error(data.message || 'Authentication failed');
    }

    // Save token and navigate to app
    localStorage.setItem('cropiq_token', data.token);
    localStorage.setItem('cropiq_user', JSON.stringify(data.user));
    
    window.location.href = '/index.html';
  } catch (err) {
    showToast('❌ ' + err.message);
  }
});

function showToast(msg, dur = 2800) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(t._tid);
  t._tid = setTimeout(() => t.classList.remove('show'), dur);
}

// Redirect to index if already logged in
if (localStorage.getItem('cropiq_token')) {
  window.location.href = '/index.html';
}
