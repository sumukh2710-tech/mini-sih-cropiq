/* ═══════════════════════════════════════
   CropIQ — Frontend App (API-integrated)
═══════════════════════════════════════ */

const API = '';  // same origin — Express serves both

/* ── Helpers ───────────────────────────────────────── */
async function apiFetch(url, opts = {}) {
  const token = localStorage.getItem('cropiq_token');
  try {
    const res = await fetch(API + url, {
      headers: { 
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': 'Bearer ' + token } : {})
      },
      ...opts
    });
    
    if (res.status === 401 || res.status === 403) {
      localStorage.removeItem('cropiq_token');
      localStorage.removeItem('cropiq_user');
      window.location.href = '/login.html';
      return null;
    }
    
    const json = await res.json();
    if (!json.success) throw new Error(json.message || 'API error');
    return json.data;
  } catch (err) {
    console.error('API error', url, err.message);
    showToast('⚠️ ' + err.message);
    return null;
  }
}

/* ── Dark Mode ─────────────────────────────────────── */
function toggleDark() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
  localStorage.setItem('cropiq-theme', isDark ? 'light' : 'dark');
  const sBtn = document.getElementById('settingsDarkBtn');
  if (sBtn) sBtn.classList.toggle('on', !isDark);
  setTimeout(() => { if (adminChartsInit) initAdminCharts(); }, 350);
}
(function () {
  const token = localStorage.getItem('cropiq_token');
  if (!token) {
    window.location.href = '/login.html';
    return;
  }
  
  const user = JSON.parse(localStorage.getItem('cropiq_user') || '{}');
  if (user && user.role === 'admin') {
    document.getElementById('appSwitcher').style.display = 'flex';
  } else {
    document.getElementById('appSwitcher').style.display = 'none';
  }
  
  const saved = localStorage.getItem('cropiq-theme');
  if (saved) document.documentElement.setAttribute('data-theme', saved);
  const sBtn = document.getElementById('settingsDarkBtn');
  if (sBtn && saved === 'dark') sBtn.classList.add('on');
})();

/* ── App Switcher ──────────────────────────────────── */
let adminChartsInit = false;

function switchApp(which) {
  const mainApp = document.getElementById('main-app');
  const adminApp = document.getElementById('admin-app');
  const tabMain = document.getElementById('tab-main');
  const tabAdmin = document.getElementById('tab-admin');
  const mainCta = document.getElementById('mainCta');
  const mainNav = document.getElementById('mainNav');
  if (which === 'admin') {
    mainApp.style.display = 'none';
    adminApp.style.display = 'block';
    tabMain.classList.remove('active'); tabAdmin.classList.add('active');
    mainCta.style.display = 'none'; mainNav.style.display = 'none';
    if (!adminChartsInit) { loadAdminData(); adminChartsInit = true; }
    showToast('🔐 Admin Dashboard loaded');
  } else {
    mainApp.style.display = 'block'; adminApp.style.display = 'none';
    tabMain.classList.add('active'); tabAdmin.classList.remove('active');
    mainCta.style.display = 'flex'; mainNav.style.display = 'flex';
  }
}

/* ── Admin Panel Navigation ────────────────────────── */
function showPanel(name) {
  document.querySelectorAll('.admin-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
  document.getElementById('panel-' + name).classList.add('active');
  document.querySelectorAll('.sidebar-link').forEach(l => {
    if (l.getAttribute('onclick') && l.getAttribute('onclick').includes("'" + name + "'"))
      l.classList.add('active');
  });
  showToast('📂 ' + name.charAt(0).toUpperCase() + name.slice(1) + ' loaded');
}

/* ── Load all admin data ───────────────────────────── */
async function loadAdminData() {
  await Promise.all([
    loadDashboardStats(),
    loadDashboardCharts(),
    loadActivityLog(),
    loadFarmers(),
    loadCropTable(),
    loadDistrictGrid()
  ]);
}

/* ── Dashboard KPIs ────────────────────────────────── */
async function loadDashboardStats() {
  const data = await apiFetch('/api/dashboard/stats');
  if (!data) return;
  document.getElementById('kpi-farmers').textContent       = data.totalFarmers.toLocaleString('en-IN');
  document.getElementById('kpi-plans').textContent         = data.totalPlans.toLocaleString('en-IN');
  document.getElementById('kpi-profit').textContent        = data.predictedProfitCr;
  document.getElementById('kpi-accuracy').textContent      = data.accuracy;
  document.getElementById('kpi-farmers-delta').textContent = data.deltaFarmers;
  document.getElementById('kpi-plans-delta').textContent   = data.deltaPlans;
  document.getElementById('kpi-profit-delta').textContent  = data.deltaProfit;
  document.getElementById('kpi-accuracy-delta').textContent= data.deltaAccuracy;
  const badge = document.getElementById('badge-farmers');
  if (badge) badge.textContent = data.totalFarmers.toLocaleString('en-IN');
}

/* ── Activity Log ──────────────────────────────────── */
async function loadActivityLog() {
  const plans = await apiFetch('/api/dashboard/activity');
  const log = document.getElementById('activityLog');
  if (!log) return;
  if (!plans || plans.length === 0) {
    log.innerHTML = '<div class="activity-item"><span class="ac-dot ac-g"></span><div class="ac-text">No activity yet — generate a plan to see it here.</div></div>';
    return;
  }
  log.innerHTML = plans.map(p => {
    const ago = timeAgo(p.createdAt);
    return `<div class="activity-item"><span class="ac-dot ac-g"></span><div class="ac-text"><strong>${p.farmerName}</strong> generated a plan — ${p.topCropEmoji} ${p.topCrop}, ${p.area} acres, ${p.location}</div><span class="ac-time">${ago}</span></div>`;
  }).join('');
}

function timeAgo(dateStr) {
  const diff = Math.floor((Date.now() - new Date(dateStr)) / 1000);
  if (diff < 60) return diff + 's ago';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  return Math.floor(diff / 86400) + 'd ago';
}

/* ── Farmers Table ─────────────────────────────────── */
async function loadFarmers() {
  const farmers = await apiFetch('/api/farmers');
  const tbody = document.getElementById('farmerTableBody');
  const title = document.getElementById('farmer-count-title');
  if (!farmers) return;
  if (title) title.textContent = farmers.length + ' registered users';
  const statusClass = { Active: 'bd-active', Pending: 'bd-pending', Inactive: 'bd-inactive' };
  const statusDot   = { Active: '●', Pending: '⏳', Inactive: '✕' };
  tbody.innerHTML = farmers.map(f => `
    <tr class="crop-perf-row">
      <td>${f.farmerId || '—'}</td>
      <td class="td-name">${f.name}</td>
      <td>${f.district}</td>
      <td>${f.plans}</td>
      <td>${f.topCropEmoji || ''} ${f.topCrop || '—'}</td>
      <td><span class="td-badge ${statusClass[f.status] || 'bd-active'}">${statusDot[f.status] || '●'} ${f.status}</span></td>
      <td class="td-act">
        <button class="act-btn act-view" onclick="showToast('👁 Viewing ${f.name}')">View</button>
        <button class="act-btn act-del"  onclick="deleteFarmer('${f._id}','${f.name}')">Delete</button>
      </td>
    </tr>`).join('');
}

async function deleteFarmer(id, name) {
  if (!confirm(`Delete farmer: ${name}?`)) return;
  const result = await apiFetch('/api/farmers/' + id, { method: 'DELETE' });
  if (result !== null) { showToast('🗑 ' + name + ' deleted'); loadFarmers(); loadDashboardStats(); }
}

async function submitAddFarmer() {
  const name     = document.getElementById('af-name').value.trim();
  const district = document.getElementById('af-district').value.trim();
  const crop     = document.getElementById('af-crop').value.trim();
  const status   = document.getElementById('af-status').value;
  if (!name || !district) { showToast('⚠️ Name and District are required'); return; }
  const result = await apiFetch('/api/farmers', {
    method: 'POST',
    body: JSON.stringify({ name, district, topCrop: crop, status })
  });
  if (result) {
    showToast('✅ Farmer ' + name + ' added!');
    closeModal('addFarmerModal');
    ['af-name','af-district','af-crop'].forEach(id => { document.getElementById(id).value = ''; });
    loadFarmers(); loadDashboardStats();
  }
}

/* ── Crop Analytics Table ──────────────────────────── */
async function loadCropTable() {
  const crops = await apiFetch('/api/crops/all');
  const tbody = document.getElementById('cropTableBody');
  if (!crops || !tbody) return;
  const maxP = Math.max(...crops.map(c => c.profit));
  const riskClass = { Low: 'bd-active', Medium: 'bd-pending', High: 'bd-inactive' };
  const barClass  = { Low: 'pf-g', Medium: 'pf-a', High: 'pf-r' };
  tbody.innerHTML = crops.map(c => {
    const pct = Math.round(c.profit / maxP * 100);
    return `<tr class="crop-perf-row">
      <td class="td-name">${c.emoji} ${c.name}</td>
      <td style="text-transform:capitalize">${c.season === 'yearround' ? 'Year-Round' : c.season.charAt(0).toUpperCase()+c.season.slice(1)}</td>
      <td>₹${c.profit.toLocaleString('en-IN')}</td>
      <td><span class="td-badge ${riskClass[c.risk]}">${c.risk}</span></td>
      <td class="perf-bar-wrap"><div class="perf-bar"><div class="perf-bar-fill ${barClass[c.risk]}" style="width:${pct}%"></div></div> ${pct}%</td>
    </tr>`;
  }).join('');
}

/* ── District Heatmap ──────────────────────────────── */
async function loadDistrictGrid() {
  const districts = await apiFetch('/api/districts');
  const grid = document.getElementById('districtGrid');
  if (!districts || !grid) return;
  const maxP = Math.max(...districts.map(d => d.plans));
  grid.innerHTML = '';
  districts.forEach((d, i) => {
    const pct = Math.round(d.plans / maxP * 100);
    const div = document.createElement('div');
    div.className = `district-cell dc-heat-${d.heat}`;
    div.innerHTML = `<div class="dc-name">📍 ${d.name}</div><div class="dc-val">${d.farmers}</div><div style="font-size:.68rem;color:var(--txt3);margin-bottom:.4rem">${d.plans} plans</div><div class="dc-bar-bg"><div class="dc-bar-fg" data-pct="${pct}" style="width:0%"></div></div>`;
    div.onclick = () => showToast(`📍 ${d.name}: ${d.farmers} farmers, ${d.plans} plans`);
    grid.appendChild(div);
    setTimeout(() => { const fg = div.querySelector('.dc-bar-fg'); if (fg) fg.style.width = pct + '%'; }, 200 + i * 60);
  });
  // also update district chart if already initialized
  if (adminChartInstances.districtChart) {
    adminChartInstances.districtChart.data.labels   = districts.slice(0,8).map(d => d.name);
    adminChartInstances.districtChart.data.datasets[0].data = districts.slice(0,8).map(d => d.plans);
    adminChartInstances.districtChart.update();
  }
}

/* ── Table Filter ──────────────────────────────────── */
function filterTable(input, tableId) {
  const v = input.value.toLowerCase();
  document.querySelectorAll('#' + tableId + ' tbody tr').forEach(tr => {
    tr.style.display = tr.textContent.toLowerCase().includes(v) ? '' : 'none';
  });
}

/* ═══════════════════════════════════════
   ADMIN CHARTS
═══════════════════════════════════════ */
function getChartDefaults() {
  const dark = document.documentElement.getAttribute('data-theme') === 'dark';
  return {
    gridColor:  dark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)',
    tickColor:  dark ? '#6b8a72' : '#6b8570',
    tooltipBg:  dark ? '#162019' : '#122a18',
  };
}
const adminChartInstances = {};
function destroyChart(id) { if (adminChartInstances[id]) { adminChartInstances[id].destroy(); delete adminChartInstances[id]; } }

async function loadDashboardCharts() {
  const d = await apiFetch('/api/dashboard/charts');
  if (!d) return;
  initAdminCharts(d);
}

function initAdminCharts(d) {
  const { gridColor, tickColor, tooltipBg } = getChartDefaults();
  const font = "'Plus Jakarta Sans',sans-serif";
  const tip  = { backgroundColor: tooltipBg, titleColor: '#7dd494', bodyColor: '#fff', padding: 12, cornerRadius: 10 };

  // Activity
  destroyChart('activityChart');
  const ac = document.getElementById('activityChart');
  if (ac && d) adminChartInstances.activityChart = new Chart(ac.getContext('2d'), {
    type: 'line',
    data: { labels: d.activity.labels, datasets: [
      { label:'Plans Generated', data: d.activity.plans,   borderColor:'#2e9e45', backgroundColor:'rgba(46,158,69,.12)', fill:true, tension:.45, borderWidth:2.5, pointRadius:4, pointBackgroundColor:'#2e9e45' },
      { label:'New Farmers',     data: d.activity.farmers, borderColor:'#f59e0b', backgroundColor:'rgba(245,158,11,.08)', fill:true, tension:.45, borderWidth:2,   pointRadius:3, pointBackgroundColor:'#f59e0b' }
    ]},
    options: { responsive:true, maintainAspectRatio:false, animation:{duration:900}, plugins:{legend:{labels:{color:tickColor,font:{family:font,size:11}}},tooltip:tip}, scales:{ x:{grid:{color:gridColor},ticks:{color:tickColor,font:{family:font}}}, y:{grid:{color:gridColor},ticks:{color:tickColor,font:{family:font}},beginAtZero:true} }}
  });

  // Crop Distribution
  destroyChart('cropDistChart');
  const cd = document.getElementById('cropDistChart');
  if (cd && d) adminChartInstances.cropDistChart = new Chart(cd.getContext('2d'), {
    type: 'doughnut',
    data: { labels: d.cropDist.labels, datasets:[{ data: d.cropDist.data, backgroundColor:['rgba(46,158,69,.85)','rgba(77,191,100,.8)','rgba(245,158,11,.8)','rgba(251,191,36,.8)','rgba(14,165,233,.8)','rgba(156,163,175,.7)'], borderWidth:2, borderColor:'transparent', hoverBorderColor:'#fff' }]},
    options: { responsive:true, maintainAspectRatio:false, cutout:'65%', animation:{duration:900}, plugins:{legend:{position:'right',labels:{color:tickColor,font:{family:font,size:11},padding:14}},tooltip:{...tip,callbacks:{label:c => ` ${c.label}: ${c.raw}%`}}} }
  });

  // Season pie
  destroyChart('seasonChart');
  const sc = document.getElementById('seasonChart');
  if (sc && d) adminChartInstances.seasonChart = new Chart(sc.getContext('2d'), {
    type:'pie',
    data:{ labels: d.season.labels, datasets:[{ data: d.season.data, backgroundColor:['rgba(46,158,69,.85)','rgba(77,191,100,.8)','rgba(245,158,11,.8)','rgba(14,165,233,.75)'], borderWidth:2, borderColor:'transparent' }]},
    options:{ responsive:true, maintainAspectRatio:false, animation:{duration:900}, plugins:{legend:{position:'bottom',labels:{color:tickColor,font:{family:font,size:11}}},tooltip:tip} }
  });

  // District bar
  destroyChart('districtChart');
  const dc = document.getElementById('districtChart');
  if (dc) adminChartInstances.districtChart = new Chart(dc.getContext('2d'), {
    type:'bar',
    data:{ labels:['Mandya','Mysuru','Bengaluru','Belagavi','Shivamogga','Hassan','Tumakuru','Kalaburagi'], datasets:[{ label:'Plans', data:[1240,980,860,740,620,580,510,440], backgroundColor:'rgba(46,158,69,.78)', borderColor:'#1e5c2a', borderWidth:1.5, borderRadius:8, borderSkipped:false }]},
    options:{ responsive:true, maintainAspectRatio:false, animation:{duration:900}, plugins:{legend:{display:false},tooltip:{...tip,callbacks:{label:c => ` ${c.raw} plans`}}}, scales:{ x:{grid:{display:false},ticks:{color:tickColor,font:{family:font,size:10}}}, y:{grid:{color:gridColor},ticks:{color:tickColor,font:{family:font,size:10}},beginAtZero:true} }}
  });

  // Soil Type
  destroyChart('soilTypeChart');
  const st = document.getElementById('soilTypeChart');
  if (st) adminChartInstances.soilTypeChart = new Chart(st.getContext('2d'), {
    type:'bar',
    data:{ labels:['Red/Laterite','Black Cotton','Loamy','Sandy Loam','Alluvial','Clay'], datasets:[{ data:[48,22,14,8,5,3], backgroundColor:['rgba(220,38,38,.75)','rgba(30,30,30,.7)','rgba(120,80,40,.7)','rgba(214,188,155,.8)','rgba(14,165,233,.7)','rgba(59,130,246,.7)'], borderRadius:6, borderWidth:0 }]},
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, animation:{duration:900}, plugins:{legend:{display:false},tooltip:{...tip,callbacks:{label:c => ` ${c.raw}% of farmers`}}}, scales:{ x:{grid:{color:gridColor},ticks:{color:tickColor,font:{family:font,size:10}},beginAtZero:true}, y:{grid:{display:false},ticks:{color:tickColor,font:{family:font,size:10}}} }}
  });

  // Soil Nutrient radar
  destroyChart('soilNutrientChart');
  const sn = document.getElementById('soilNutrientChart');
  if (sn && d) adminChartInstances.soilNutrientChart = new Chart(sn.getContext('2d'), {
    type:'radar',
    data:{ labels: d.soilNutrient.labels, datasets:[
      { label:'Red Soil',  data:d.soilNutrient.red,      borderColor:'rgba(220,38,38,.8)',   backgroundColor:'rgba(220,38,38,.08)',  pointBackgroundColor:'rgba(220,38,38,.8)',   borderWidth:2 },
      { label:'Black Soil',data:d.soilNutrient.black,    borderColor:'rgba(30,30,30,.6)',    backgroundColor:'rgba(30,30,30,.06)',   pointBackgroundColor:'rgba(60,60,60,.8)',    borderWidth:2 },
      { label:'Alluvial',  data:d.soilNutrient.alluvial, borderColor:'rgba(14,165,233,.8)',  backgroundColor:'rgba(14,165,233,.08)', pointBackgroundColor:'rgba(14,165,233,.8)',  borderWidth:2 },
    ]},
    options:{ responsive:true, maintainAspectRatio:false, animation:{duration:900}, plugins:{legend:{labels:{color:tickColor,font:{family:font,size:10}}},tooltip:tip}, scales:{ r:{grid:{color:gridColor},pointLabels:{color:tickColor,font:{family:font,size:10}},ticks:{display:false},angleLines:{color:gridColor}} }}
  });

  // Soil pH
  destroyChart('soilPhChart');
  const sp = document.getElementById('soilPhChart');
  if (sp && d) adminChartInstances.soilPhChart = new Chart(sp.getContext('2d'), {
    type:'bar',
    data:{ labels: d.soilPh.labels, datasets:[{ label:'Farmers (%)', data:d.soilPh.data, backgroundColor:['rgba(239,68,68,.7)','rgba(245,158,11,.7)','rgba(46,158,69,.75)','rgba(46,158,69,.85)','rgba(245,158,11,.7)','rgba(239,68,68,.7)'], borderRadius:6, borderWidth:0 }]},
    options:{ responsive:true, maintainAspectRatio:false, animation:{duration:900}, plugins:{legend:{display:false},tooltip:{...tip,callbacks:{label:c => ` ${c.raw}% of farmers`}}}, scales:{ x:{grid:{display:false},ticks:{color:tickColor,font:{family:font,size:10}}}, y:{grid:{color:gridColor},ticks:{color:tickColor,font:{family:font,size:10}},beginAtZero:true} }}
  });

  // Yield Trend
  destroyChart('yieldTrendChart');
  const yt = document.getElementById('yieldTrendChart');
  if (yt && d) adminChartInstances.yieldTrendChart = new Chart(yt.getContext('2d'), {
    type:'line',
    data:{ labels: d.yieldTrend.labels, datasets:[
      { label:'Sugarcane', data:d.yieldTrend.sugarcane, borderColor:'#2e9e45', borderWidth:2.5, tension:.4, pointRadius:4, pointBackgroundColor:'#2e9e45', backgroundColor:'transparent' },
      { label:'Banana',    data:d.yieldTrend.banana,    borderColor:'#f59e0b', borderWidth:2,   tension:.4, pointRadius:3, pointBackgroundColor:'#f59e0b', backgroundColor:'transparent' },
      { label:'Ragi',      data:d.yieldTrend.ragi,      borderColor:'#0ea5e9', borderWidth:2,   tension:.4, pointRadius:3, pointBackgroundColor:'#0ea5e9', backgroundColor:'transparent' },
    ]},
    options:{ responsive:true, maintainAspectRatio:false, animation:{duration:900}, plugins:{legend:{labels:{color:tickColor,font:{family:font,size:11}}},tooltip:{...tip,callbacks:{label:c => ` ₹${c.raw}K/acre`}}}, scales:{ x:{grid:{color:gridColor},ticks:{color:tickColor,font:{family:font}}}, y:{grid:{color:gridColor},ticks:{color:tickColor,font:{family:font},callback:v => `₹${v}K`},beginAtZero:false} }}
  });

  // Rainfall
  destroyChart('rainfallChart');
  const rf = document.getElementById('rainfallChart');
  if (rf && d) adminChartInstances.rainfallChart = new Chart(rf.getContext('2d'), {
    type:'bar',
    data:{ labels: d.rainfall.labels, datasets:[
      { label:'Bengaluru', data:d.rainfall.bengaluru, backgroundColor:'rgba(46,158,69,.7)',  borderRadius:5, borderSkipped:false },
      { label:'Mandya',    data:d.rainfall.mandya,    backgroundColor:'rgba(245,158,11,.65)',borderRadius:5, borderSkipped:false },
      { label:'Belagavi',  data:d.rainfall.belagavi,  backgroundColor:'rgba(239,68,68,.65)', borderRadius:5, borderSkipped:false },
    ]},
    options:{ responsive:true, maintainAspectRatio:false, animation:{duration:900}, plugins:{legend:{labels:{color:tickColor,font:{family:font,size:11}}},tooltip:{...tip,callbacks:{label:c => ` ${c.raw}mm`}}}, scales:{ x:{grid:{display:false},ticks:{color:tickColor,font:{family:font,size:10}}}, y:{grid:{color:gridColor},ticks:{color:tickColor,font:{family:font},callback:v => `${v}mm`},beginAtZero:true} }}
  });
}

/* ═══════════════════════════════════════
   PLANNER — API-integrated
═══════════════════════════════════════ */
const SLABELS = { kharif:'Kharif (Jun–Oct)', rabi:'Rabi (Nov–Apr)', zaid:'Zaid / Summer (Mar–Jun)', yearround:'Year-Round' };
let chartInst = null;

function gotoPlanner() {
  const sc = document.getElementById('slideContainer');
  if (sc.classList.contains('show-results')) goToForm();
  else sc.scrollIntoView({ behavior:'smooth', block:'start' });
}
function goToSlide(slide) {
  const sc = document.getElementById('slideContainer');
  if (slide === 'results') { sc.classList.add('show-results'); setTimeout(() => sc.scrollIntoView({ behavior:'smooth', block:'start' }), 60); }
  else { sc.classList.remove('show-results'); setTimeout(() => sc.scrollIntoView({ behavior:'smooth', block:'start' }), 60); }
}
function goToForm() { goToSlide('form'); }
function scrollToTop() { window.scrollTo({ top:0, behavior:'smooth' }); }
function setLoc(district) {
  const input = document.getElementById('f-loc');
  input.value = district + ', Karnataka';
  input.classList.remove('err');
  showToast('📍 Location set to ' + district);
}
function setLocAndPlan(district) { setLoc(district); gotoPlanner(); }

const REQ_IDS = ['f-loc','f-soil','f-area','f-budget','f-season'];
REQ_IDS.forEach(id => {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('input',  () => el.classList.remove('err'));
  el.addEventListener('change', () => el.classList.remove('err'));
});

function validate() {
  let ok = true;
  REQ_IDS.forEach(id => {
    const el = document.getElementById(id); if (!el) return;
    const val = el.value.toString().trim();
    const empty = val === '' || (el.type === 'number' && parseFloat(val) <= 0);
    if (empty) { el.classList.add('err'); ok = false; } else el.classList.remove('err');
  });
  return ok;
}

document.getElementById('planForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  if (!validate()) {
    this.animate([{transform:'translateX(0)'},{transform:'translateX(-9px)'},{transform:'translateX(9px)'},{transform:'translateX(0)'}], {duration:380,easing:'ease-in-out'});
    showToast('⚠️ Please fill in all required fields');
    return;
  }
  const btn = document.getElementById('subBtn');
  const lbl = document.getElementById('subLabel');
  const sp  = document.getElementById('spin');
  btn.disabled = true; lbl.classList.add('hidden'); sp.classList.remove('hidden');
  await buildResults();
  btn.disabled = false; lbl.classList.remove('hidden'); sp.classList.add('hidden');
});

async function buildResults() {
  const loc    = document.getElementById('f-loc').value.trim();
  const soilEl = document.getElementById('f-soil');
  const area   = parseFloat(document.getElementById('f-area').value) || 1;
  const budget = parseFloat(document.getElementById('f-budget').value) || 0;
  const season = document.getElementById('f-season').value || 'yearround';
  const water  = document.getElementById('f-water').value || '';
  const name   = document.getElementById('f-name').value.trim() || 'Anonymous';

  // Fetch recommendations from backend
  const crops = await apiFetch(`/api/crops?season=${season}&soil=${soilEl.value}&area=${area}&budget=${budget}`);
  if (!crops || crops.length === 0) { showToast('⚠️ No crops found for this season'); return; }

  // Update banner
  document.getElementById('rb-loc').textContent    = loc || 'Karnataka';
  document.getElementById('rb-season').textContent = SLABELS[season] || season;
  document.getElementById('rb-area').textContent   = area + ' Acres';
  document.getElementById('rb-budget').textContent = '₹' + budget.toLocaleString('en-IN');
  document.getElementById('rb-soil').textContent   = soilEl.options[soilEl.selectedIndex]?.text?.replace(' (most common in Karnataka)','') || '—';

  renderCards(crops, area);
  renderChart(crops);
  renderRisk(crops);
  renderCalendar(crops[0].cal);
  goToSlide('results');
  showToast('✅ Analysis complete!');

  // Save plan to DB (fire and forget)
  apiFetch('/api/plans', {
    method: 'POST',
    body: JSON.stringify({
      farmerName: name, location: loc, soil: soilEl.value,
      area, budget, season, water,
      topCrop: crops[0].name, topCropEmoji: crops[0].emoji
    })
  });

  // Increment district plan count
  const district = loc.split(',')[0].trim();
  apiFetch('/api/districts/' + encodeURIComponent(district) + '/increment', { method:'POST' });
}

function renderCards(crops, area) {
  const grid = document.getElementById('cropGrid'); grid.innerHTML = '';
  const maxP = Math.max(...crops.map(c => c.profit));
  const rMap = { Low:'rl', Medium:'rm', High:'rh' };
  const rEmo = { Low:'🟢', Medium:'🟡', High:'🔴' };
  crops.forEach((c, i) => {
    const pct = Math.round(c.profit / maxP * 100);
    const div = document.createElement('div'); div.className = 'cc';
    div.innerHTML = `${i===0?'<div class="cc-badge">🥇 #1 Pick</div>':''}<span class="cc-emo">${c.emoji}</span><div class="cc-name">${c.name}</div><span class="cc-plbl">Expected Profit (${area} Acres)</span><div class="cc-profit">₹${c.profit.toLocaleString('en-IN')}</div><span class="cc-risk ${rMap[c.risk]||'rl'}">${rEmo[c.risk]} ${c.risk} Risk</span><div class="pbar-bg"><div class="pbar-fg" data-pct="${pct}" style="width:0%"></div></div><div class="cc-div"></div><div class="cc-why"><strong>Why this crop?</strong>${c.reason}</div>`;
    grid.appendChild(div);
    setTimeout(() => { div.style.transition='opacity .55s ease,transform .55s ease'; div.classList.add('show'); }, 80+i*120);
    setTimeout(() => { const fg = div.querySelector('.pbar-fg'); if(fg) fg.style.width = fg.dataset.pct+'%'; }, 300+i*120);
  });
}

function renderChart(crops) {
  if (chartInst) { chartInst.destroy(); chartInst = null; }
  const dark = document.documentElement.getAttribute('data-theme') === 'dark';
  const ctx  = document.getElementById('profitChart').getContext('2d');
  chartInst  = new Chart(ctx, {
    type:'bar',
    data:{ labels:crops.map(c=>c.name), datasets:[{ label:'Profit (₹)', data:crops.map(c=>c.profit), backgroundColor:['rgba(46,158,69,.82)','rgba(77,191,100,.75)','rgba(245,158,11,.80)'], borderColor:['#1e5c2a','#2e9e45','#b45309'], borderWidth:2, borderRadius:12, borderSkipped:false }]},
    options:{ responsive:true, maintainAspectRatio:false, animation:{duration:1100,easing:'easeOutQuart'}, plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>' ₹'+c.raw.toLocaleString('en-IN')},backgroundColor:dark?'#162019':'#122a18',titleColor:'#7dd494',bodyColor:'#fff',padding:13,cornerRadius:10}}, scales:{ x:{grid:{display:false},ticks:{color:dark?'#6b8a72':'#6b8570',font:{family:"'Plus Jakarta Sans',sans-serif",size:12,weight:'600'}}}, y:{grid:{color:dark?'rgba(255,255,255,.06)':'rgba(0,0,0,.04)'},ticks:{color:dark?'#6b8a72':'#6b8570',font:{size:11},callback:v=>'₹'+(v>=1000?(v/1000).toFixed(0)+'K':v)},beginAtZero:true} }}
  });
}

function renderRisk(crops) {
  const cont = document.getElementById('riskList'); cont.innerHTML = '';
  const cfg = { Low:{cls:'rg',pct:28,lbl:'Minimal loss exposure — highly recommended'}, Medium:{cls:'ra',pct:62,lbl:'Moderate variance — plan contingencies'}, High:{cls:'rr',pct:90,lbl:'High price / weather exposure'} };
  crops.forEach((c, i) => {
    const r   = cfg[c.risk] || cfg.Low;
    const div = document.createElement('div'); div.className = 'ri-item';
    div.innerHTML = `<div class="ri-dot ${r.cls}"></div><div style="flex:1;min-width:0"><div class="ri-name">${c.emoji} ${c.name}</div><div class="ri-sub">${r.lbl}</div><div class="ri-track"><div class="ri-fill ${r.cls}" data-pct="${r.pct}" style="width:0%"></div></div></div>`;
    cont.appendChild(div);
    setTimeout(() => { const f = div.querySelector('.ri-fill'); if(f) f.style.width = f.dataset.pct+'%'; }, 350+i*100);
  });
}

function renderCalendar(cal) {
  const tl = document.getElementById('farmCal'); tl.innerHTML = '';
  (cal || []).forEach(entry => {
    const d = document.createElement('div'); d.className = 'tl-item';
    d.innerHTML = `<div class="tl-dot"></div><div class="tl-mo">${entry.m}</div><div class="tl-task">${entry.t}</div>`;
    tl.appendChild(d);
  });
}

function resetPlanner() {
  document.getElementById('planForm').reset();
  document.getElementById('cropGrid').innerHTML = '';
  document.getElementById('riskList').innerHTML = '';
  document.getElementById('farmCal').innerHTML = '';
  if (chartInst) { chartInst.destroy(); chartInst = null; }
  goToSlide('form');
  showToast('🔄 Planner reset — ready for new inputs!');
}

/* ── Modals & Utilities ────────────────────────────── */
function showToast(msg, dur = 2800) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(t._tid);
  t._tid = setTimeout(() => t.classList.remove('show'), dur);
}
function openModal(id)  { document.getElementById(id).classList.add('open');    document.body.style.overflow = 'hidden'; }
function closeModal(id) { document.getElementById(id).classList.remove('open'); document.body.style.overflow = ''; }
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { ['videoModal','shareModal','addFarmerModal'].forEach(id => document.getElementById(id)?.classList.remove('open')); document.body.style.overflow = ''; }
});

function toggleLangMenu() { document.getElementById('langDropdown').classList.toggle('open'); }

function logout() {
  localStorage.removeItem('cropiq_token');
  localStorage.removeItem('cropiq_user');
  window.location.href = '/login.html';
}

function setLang(code, label) {
  document.getElementById('langLabel').textContent = label;
  document.getElementById('langDropdown').classList.remove('open');
  const msgs = { en:'🌐 Language set to English', kn:'🌐 ಭಾಷೆ ಕನ್ನಡಕ್ಕೆ ಬದಲಾಯಿಸಲಾಗಿದೆ', hi:'🌐 भाषा हिंदी में बदली गई', te:'🌐 భాష తెలుగుకు మార్చబడింది' };
  showToast(msgs[code] || '🌐 Language changed');
  document.querySelectorAll('.lang-opt').forEach(el => el.classList.toggle('selected', el.textContent.trim().toLowerCase().includes(label.toLowerCase()) || (code==='en' && el.textContent.includes('English'))));
}
document.addEventListener('click', e => {
  const wrap = document.getElementById('langBtn')?.closest('.lang-wrap');
  if (wrap && !wrap.contains(e.target)) document.getElementById('langDropdown').classList.remove('open');
});

function shareWhatsApp() {
  const loc = document.getElementById('rb-loc').textContent;
  window.open('https://wa.me/?text=' + encodeURIComponent(`🌾 *CropIQ Crop Report*\n📍 ${loc}\nGet your free crop recommendation at CropIQ!`), '_blank');
  closeModal('shareModal'); showToast('💬 Opening WhatsApp...');
}
function copyLink() {
  const url = location.origin + '/report?loc=' + encodeURIComponent(document.getElementById('rb-loc').textContent);
  navigator.clipboard.writeText(url).then(() => showToast('🔗 Link copied!')).catch(() => showToast('🔗 Link: ' + url));
  closeModal('shareModal');
}
function downloadReport() { showToast('📥 Preparing your PDF report...', 3000); setTimeout(() => window.print(), 500); closeModal('shareModal'); }
function shareSMS() {
  window.open('sms:?body=' + encodeURIComponent(`CropIQ Report for ${document.getElementById('rb-loc').textContent} - ${location.origin}`), '_blank');
  closeModal('shareModal'); showToast('📱 Opening SMS...');
}

/* ── Scroll & Load ─────────────────────────────────── */
window.addEventListener('scroll', () => document.getElementById('hdr').classList.toggle('scrolled', window.scrollY > 50));
window.addEventListener('load', () => {
  setTimeout(() => {
    [['pb1','92%'],['pb2','78%'],['pb3','60%']].forEach(([id,w],i) =>
      setTimeout(() => { const el = document.getElementById(id); if(el){ el.style.transition='width 1.2s ease'; el.style.width=w; } }, i*140)
    );
  }, 700);
});
