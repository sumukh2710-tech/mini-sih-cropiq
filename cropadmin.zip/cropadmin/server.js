require('dotenv').config();
const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
const path     = require('path');

const app = express();

// ── Middleware ──────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Static frontend ────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

const { verifyToken, isAdmin } = require('./middleware/auth');

// ── API Routes (Public) ────────────────────────────────
app.use('/api/auth', require('./routes/auth'));

// ── API Routes (Protected) ─────────────────────────────
app.use('/api/crops',     verifyToken, require('./routes/crops'));
app.use('/api/districts', verifyToken, require('./routes/districts'));
app.use('/api/plans',     verifyToken, require('./routes/plans'));

// ── API Routes (Admin Only) ────────────────────────────
app.use('/api/farmers',   verifyToken, isAdmin, require('./routes/farmers'));
app.use('/api/dashboard', verifyToken, isAdmin, require('./routes/dashboard'));

// ── 404 API fallback ───────────────────────────────────
app.use('/api', (req, res) => {
  res.status(404).json({ success: false, message: 'API endpoint not found' });
});

// ── SPA fallback — serve index.html for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── MongoDB + Start ────────────────────────────────────
const PORT     = process.env.PORT     || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/cropiq';

mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB connected:', MONGO_URI);
    app.listen(PORT, () => {
      console.log(`🌾 CropIQ server running → http://localhost:${PORT}`);
      console.log('   Run "node seed.js" first if starting fresh.');
    });
  })
  .catch(err => {
    console.error('❌ MongoDB connection failed:', err.message);
    process.exit(1);
  });
